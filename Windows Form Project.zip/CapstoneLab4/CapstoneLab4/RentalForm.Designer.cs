﻿namespace CapstoneLab4
{
    partial class RentalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label firstNameLabel;
            System.Windows.Forms.Label lastNameLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label cityLabel;
            System.Windows.Forms.Label stateLabel;
            System.Windows.Forms.Label zIPLabel;
            this.btnBack = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.capstoneLab4DataSet = new CapstoneLab4.CapstoneLab4DataSet();
            this.tblCustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblCustomerTableAdapter = new CapstoneLab4.CapstoneLab4DataSetTableAdapters.tblCustomerTableAdapter();
            this.tableAdapterManager = new CapstoneLab4.CapstoneLab4DataSetTableAdapters.TableAdapterManager();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.stateTextBox = new System.Windows.Forms.TextBox();
            this.zIPTextBox = new System.Windows.Forms.TextBox();
            this.txtMilesBox = new System.Windows.Forms.TextBox();
            this.txtDaysBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLuxury = new System.Windows.Forms.RadioButton();
            this.btnStandard = new System.Windows.Forms.RadioButton();
            this.btnCompact = new System.Windows.Forms.RadioButton();
            this.btnClear = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTotalBox = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rentalComboBox = new System.Windows.Forms.ComboBox();
            firstNameLabel = new System.Windows.Forms.Label();
            lastNameLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            cityLabel = new System.Windows.Forms.Label();
            stateLabel = new System.Windows.Forms.Label();
            zIPLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.capstoneLab4DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            firstNameLabel.AutoSize = true;
            firstNameLabel.Location = new System.Drawing.Point(24, 27);
            firstNameLabel.Name = "firstNameLabel";
            firstNameLabel.Size = new System.Drawing.Size(60, 13);
            firstNameLabel.TabIndex = 7;
            firstNameLabel.Text = "First Name:";
            // 
            // lastNameLabel
            // 
            lastNameLabel.AutoSize = true;
            lastNameLabel.Location = new System.Drawing.Point(23, 53);
            lastNameLabel.Name = "lastNameLabel";
            lastNameLabel.Size = new System.Drawing.Size(61, 13);
            lastNameLabel.TabIndex = 9;
            lastNameLabel.Text = "Last Name:";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(36, 79);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(48, 13);
            addressLabel.TabIndex = 11;
            addressLabel.Text = "Address:";
            // 
            // cityLabel
            // 
            cityLabel.AutoSize = true;
            cityLabel.Location = new System.Drawing.Point(57, 105);
            cityLabel.Name = "cityLabel";
            cityLabel.Size = new System.Drawing.Size(27, 13);
            cityLabel.TabIndex = 13;
            cityLabel.Text = "City:";
            // 
            // stateLabel
            // 
            stateLabel.AutoSize = true;
            stateLabel.Location = new System.Drawing.Point(49, 131);
            stateLabel.Name = "stateLabel";
            stateLabel.Size = new System.Drawing.Size(35, 13);
            stateLabel.TabIndex = 15;
            stateLabel.Text = "State:";
            // 
            // zIPLabel
            // 
            zIPLabel.AutoSize = true;
            zIPLabel.Location = new System.Drawing.Point(57, 157);
            zIPLabel.Name = "zIPLabel";
            zIPLabel.Size = new System.Drawing.Size(27, 13);
            zIPLabel.TabIndex = 17;
            zIPLabel.Text = "ZIP:";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(139, 494);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 40);
            this.btnBack.TabIndex = 0;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(539, 494);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(100, 40);
            this.btnSubmit.TabIndex = 1;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(247, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(299, 55);
            this.label1.TabIndex = 2;
            this.label1.Text = "Rental Form";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(204, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(386, 37);
            this.label2.TabIndex = 3;
            this.label2.Text = "Please Fill Out the Form";
            // 
            // capstoneLab4DataSet
            // 
            this.capstoneLab4DataSet.DataSetName = "CapstoneLab4DataSet";
            this.capstoneLab4DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblCustomerBindingSource
            // 
            this.tblCustomerBindingSource.DataMember = "tblCustomer";
            this.tblCustomerBindingSource.DataSource = this.capstoneLab4DataSet;
            // 
            // tblCustomerTableAdapter
            // 
            this.tblCustomerTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tblCustomerTableAdapter = this.tblCustomerTableAdapter;
            this.tableAdapterManager.tblLotCarsTableAdapter = null;
            this.tableAdapterManager.tblRentedCarsTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = CapstoneLab4.CapstoneLab4DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCustomerBindingSource, "FirstName", true));
            this.firstNameTextBox.Location = new System.Drawing.Point(98, 24);
            this.firstNameTextBox.MaxLength = 30;
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(174, 20);
            this.firstNameTextBox.TabIndex = 8;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCustomerBindingSource, "LastName", true));
            this.lastNameTextBox.Location = new System.Drawing.Point(98, 50);
            this.lastNameTextBox.MaxLength = 30;
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(174, 20);
            this.lastNameTextBox.TabIndex = 10;
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCustomerBindingSource, "Address", true));
            this.addressTextBox.Location = new System.Drawing.Point(98, 76);
            this.addressTextBox.MaxLength = 50;
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(174, 20);
            this.addressTextBox.TabIndex = 12;
            // 
            // cityTextBox
            // 
            this.cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCustomerBindingSource, "City", true));
            this.cityTextBox.Location = new System.Drawing.Point(98, 102);
            this.cityTextBox.MaxLength = 20;
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(174, 20);
            this.cityTextBox.TabIndex = 14;
            // 
            // stateTextBox
            // 
            this.stateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCustomerBindingSource, "State", true));
            this.stateTextBox.Location = new System.Drawing.Point(98, 128);
            this.stateTextBox.MaxLength = 2;
            this.stateTextBox.Name = "stateTextBox";
            this.stateTextBox.Size = new System.Drawing.Size(27, 20);
            this.stateTextBox.TabIndex = 16;
            // 
            // zIPTextBox
            // 
            this.zIPTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCustomerBindingSource, "ZIP", true));
            this.zIPTextBox.Location = new System.Drawing.Point(98, 154);
            this.zIPTextBox.MaxLength = 5;
            this.zIPTextBox.Name = "zIPTextBox";
            this.zIPTextBox.Size = new System.Drawing.Size(77, 20);
            this.zIPTextBox.TabIndex = 18;
            this.zIPTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.zIPTextBox_KeyPress);
            // 
            // txtMilesBox
            // 
            this.txtMilesBox.Location = new System.Drawing.Point(349, 51);
            this.txtMilesBox.Name = "txtMilesBox";
            this.txtMilesBox.Size = new System.Drawing.Size(100, 20);
            this.txtMilesBox.TabIndex = 21;
            this.txtMilesBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMilesBox_KeyPress);
            // 
            // txtDaysBox
            // 
            this.txtDaysBox.Location = new System.Drawing.Point(349, 22);
            this.txtDaysBox.Name = "txtDaysBox";
            this.txtDaysBox.Size = new System.Drawing.Size(100, 20);
            this.txtDaysBox.TabIndex = 19;
            this.txtDaysBox.TextChanged += new System.EventHandler(this.txtDaysBox_TextChanged);
            this.txtDaysBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDaysBox_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(188, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Number of Miles ($0.32/1 Mile):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(257, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Number of Days:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLuxury);
            this.groupBox1.Controls.Add(this.btnStandard);
            this.groupBox1.Controls.Add(this.btnCompact);
            this.groupBox1.Location = new System.Drawing.Point(15, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(155, 120);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Car Model Type";
            // 
            // btnLuxury
            // 
            this.btnLuxury.AutoSize = true;
            this.btnLuxury.Location = new System.Drawing.Point(9, 94);
            this.btnLuxury.Name = "btnLuxury";
            this.btnLuxury.Size = new System.Drawing.Size(122, 17);
            this.btnLuxury.TabIndex = 2;
            this.btnLuxury.Text = "Luxury ($39.00/Day)";
            this.btnLuxury.UseVisualStyleBackColor = true;
            // 
            // btnStandard
            // 
            this.btnStandard.AutoSize = true;
            this.btnStandard.Location = new System.Drawing.Point(9, 61);
            this.btnStandard.Name = "btnStandard";
            this.btnStandard.Size = new System.Drawing.Size(134, 17);
            this.btnStandard.TabIndex = 1;
            this.btnStandard.Text = "Standard ($24.95/Day)";
            this.btnStandard.UseVisualStyleBackColor = true;
            this.btnStandard.CheckedChanged += new System.EventHandler(this.btnStandard_CheckedChanged);
            // 
            // btnCompact
            // 
            this.btnCompact.AutoSize = true;
            this.btnCompact.Checked = true;
            this.btnCompact.Location = new System.Drawing.Point(9, 28);
            this.btnCompact.Name = "btnCompact";
            this.btnCompact.Size = new System.Drawing.Size(133, 17);
            this.btnCompact.TabIndex = 0;
            this.btnCompact.TabStop = true;
            this.btnCompact.Text = "Compact ($19.95/Day)";
            this.btnCompact.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(273, 100);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 25;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(251, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "Total Rental Cost:";
            // 
            // txtTotalBox
            // 
            this.txtTotalBox.Location = new System.Drawing.Point(350, 146);
            this.txtTotalBox.Name = "txtTotalBox";
            this.txtTotalBox.Size = new System.Drawing.Size(100, 20);
            this.txtTotalBox.TabIndex = 26;
            this.txtTotalBox.TextChanged += new System.EventHandler(this.txtTotalBox_TextChanged);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(370, 100);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 28;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click_2);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(firstNameLabel);
            this.groupBox2.Controls.Add(this.zIPTextBox);
            this.groupBox2.Controls.Add(zIPLabel);
            this.groupBox2.Controls.Add(this.stateTextBox);
            this.groupBox2.Controls.Add(stateLabel);
            this.groupBox2.Controls.Add(this.cityTextBox);
            this.groupBox2.Controls.Add(cityLabel);
            this.groupBox2.Controls.Add(this.addressTextBox);
            this.groupBox2.Controls.Add(addressLabel);
            this.groupBox2.Controls.Add(this.lastNameTextBox);
            this.groupBox2.Controls.Add(lastNameLabel);
            this.groupBox2.Controls.Add(this.firstNameTextBox);
            this.groupBox2.Location = new System.Drawing.Point(12, 155);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(278, 196);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Customer Info";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.btnCalculate);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtDaysBox);
            this.groupBox3.Controls.Add(this.txtTotalBox);
            this.groupBox3.Controls.Add(this.txtMilesBox);
            this.groupBox3.Controls.Add(this.btnClear);
            this.groupBox3.Location = new System.Drawing.Point(296, 155);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(470, 196);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Estimate Your Price";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 365);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 13);
            this.label7.TabIndex = 32;
            this.label7.Text = "Please Select a Car to Rent:";
            // 
            // rentalComboBox
            // 
            this.rentalComboBox.FormattingEnabled = true;
            this.rentalComboBox.Location = new System.Drawing.Point(182, 362);
            this.rentalComboBox.Name = "rentalComboBox";
            this.rentalComboBox.Size = new System.Drawing.Size(408, 21);
            this.rentalComboBox.TabIndex = 33;
            // 
            // RentalForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.rentalComboBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnBack);
            this.Name = "RentalForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jacob\'s Car Rentals";
            this.Load += new System.EventHandler(this.RentalForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.capstoneLab4DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private CapstoneLab4DataSet capstoneLab4DataSet;
        private System.Windows.Forms.BindingSource tblCustomerBindingSource;
        private CapstoneLab4DataSetTableAdapters.tblCustomerTableAdapter tblCustomerTableAdapter;
        private CapstoneLab4DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox stateTextBox;
        private System.Windows.Forms.TextBox zIPTextBox;
        private System.Windows.Forms.TextBox txtMilesBox;
        private System.Windows.Forms.TextBox txtDaysBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton btnLuxury;
        private System.Windows.Forms.RadioButton btnStandard;
        private System.Windows.Forms.RadioButton btnCompact;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTotalBox;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox rentalComboBox;
    }
}