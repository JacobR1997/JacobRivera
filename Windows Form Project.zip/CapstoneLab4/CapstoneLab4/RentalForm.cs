﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace CapstoneLab4
{
    public partial class RentalForm : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public RentalForm()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\jriv1_000\Desktop\CapstoneLab4.mdb";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();

            InitialForm initialForm = new InitialForm();
            initialForm.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tblCustomerBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tblCustomerBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.capstoneLab4DataSet);

        }

        private void RentalForm_Load(object sender, EventArgs e)
        {
            //COMBOBOX TEST
            connection.Open();
            string strSQL = "SELECT * FROM [tblLotCars]";
            OleDbDataAdapter adapter = new OleDbDataAdapter(new OleDbCommand(strSQL, connection));
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            rentalComboBox.DataSource = ds.Tables[0];
            rentalComboBox.DisplayMember = "Car";
            rentalComboBox.ValueMember = "Car"; 

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try {
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "insert into tblCustomer (FirstName, LastName, Address, City, State, ZIP, CarRented) values('" + firstNameTextBox.Text + "','" + lastNameTextBox.Text + "','" + addressTextBox.Text + "','" + cityTextBox.Text + "','" + stateTextBox.Text + "','" + zIPTextBox.Text + "','" + rentalComboBox.Text + "')";

                if (string.IsNullOrWhiteSpace(firstNameTextBox.Text) && string.IsNullOrWhiteSpace(lastNameTextBox.Text) && string.IsNullOrWhiteSpace(addressTextBox.Text) && string.IsNullOrWhiteSpace(cityTextBox.Text) && string.IsNullOrWhiteSpace(stateTextBox.Text) && string.IsNullOrWhiteSpace(zIPTextBox.Text))
                {
                    // Message box
                    MessageBox.Show("Please enter text box info");
                }
                else
                {
                    command.ExecuteNonQuery();
                    MessageBox.Show("Rental Submitted");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }
        }

        private void zIPTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if(!Char.IsDigit(ch) && ch != 8  && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDaysBox.Clear();
            txtMilesBox.Clear();
            txtTotalBox.Clear();
            btnCompact.Checked = true;
            txtDaysBox.Focus();
        }

      

        private void btnStandard_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click_2(object sender, EventArgs e)
        {
            float day, total, mile;

            if (txtDaysBox.Text == "" || txtMilesBox.Text == "")
            {
                MessageBox.Show("Enter the required fields above!");
            }
            else
            {
                day = float.Parse(txtDaysBox.Text);
                mile = float.Parse(txtMilesBox.Text);
                total = 0;

                if (btnCompact.Checked)
                {
                    total = (0.32f * mile) + (19.95f * day);
                }
                else if (btnStandard.Checked)
                {
                    total = (0.32f * mile) + (24.95f * day);
                }
                else if (btnLuxury.Checked)
                {
                    total = (0.32f * mile) + (39.00f * day);
                }
                else
                {
                    MessageBox.Show("Invalid Info");

                }

                txtTotalBox.Text = total.ToString("c");
            }
        }

        private void txtTotalBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtDaysBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDaysBox_KeyPress(object sender, KeyPressEventArgs e)
        {

            //Could calculate half days or quarter days
            if ((e.KeyChar < '0' || e.KeyChar > '9') && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
                e.Handled = true;
            if (e.KeyChar == '.')
            {
                if (txtDaysBox.Text.Contains("."))
                {
                    e.Handled = true;
                }
            }
        }

        private void txtMilesBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
                e.Handled = true;
            if (e.KeyChar == '.')
            {
                if (txtMilesBox.Text.Contains("."))
                {
                    e.Handled = true;
                }
            }
        }
    }
}
