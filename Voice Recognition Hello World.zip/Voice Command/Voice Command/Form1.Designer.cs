﻿namespace Voice_Command
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnVoiceOn = new System.Windows.Forms.Button();
            this.btnVoiceOff = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(413, 216);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "Please click Voice On to use the program! Voice Off if you want to stop picking u" +
    "p voice.";
            // 
            // btnVoiceOn
            // 
            this.btnVoiceOn.Location = new System.Drawing.Point(39, 226);
            this.btnVoiceOn.Name = "btnVoiceOn";
            this.btnVoiceOn.Size = new System.Drawing.Size(75, 23);
            this.btnVoiceOn.TabIndex = 1;
            this.btnVoiceOn.Text = "Voice On";
            this.btnVoiceOn.UseVisualStyleBackColor = true;
            this.btnVoiceOn.Click += new System.EventHandler(this.btnVoiceOn_Click);
            // 
            // btnVoiceOff
            // 
            this.btnVoiceOff.Enabled = false;
            this.btnVoiceOff.Location = new System.Drawing.Point(317, 226);
            this.btnVoiceOff.Name = "btnVoiceOff";
            this.btnVoiceOff.Size = new System.Drawing.Size(75, 23);
            this.btnVoiceOff.TabIndex = 2;
            this.btnVoiceOff.Text = "Voice Off";
            this.btnVoiceOff.UseVisualStyleBackColor = true;
            this.btnVoiceOff.Click += new System.EventHandler(this.btnVoiceOff_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 261);
            this.Controls.Add(this.btnVoiceOff);
            this.Controls.Add(this.btnVoiceOn);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Voice Command Program";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnVoiceOn;
        private System.Windows.Forms.Button btnVoiceOff;
    }
}

