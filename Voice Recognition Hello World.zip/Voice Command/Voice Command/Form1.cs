﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
// using System.Speech.Synthesis; ((SAVE FOR LAB PART 2))
// using System.Diagnostics;  ((SAVE FOR LAB PART 3))

namespace Voice_Command
{
    public partial class Form1 : Form
    {
        //set up the speech engine
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        // SpeechSynthesizer speechSynth = new SpeechSynthesizer(); //constructor with 0 arguments ((SAVE FOR LAB PART 2))


        public Form1()
        {
            InitializeComponent();
        }

        private void btnVoiceOn_Click(object sender, EventArgs e)
        {   //set our button to recognize Form1_Load
            recEngine.RecognizeAsync(RecognizeMode.Multiple); //can set voice detection to recognize multiple orders or not
            btnVoiceOff.Enabled = true;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //create our orders here in load via Choices
            Choices orders = new Choices();
            orders.Add(new string[] { "hello, it's me jacob", "i'm doing good, how about you?", "print my name please", "(part 3)i need to take notes", "(part 3)open chrome", "(part 3)what is the time" });



        //build grammerbuilder object. Tells the engine what orders will be used/refer to when recording
            GrammarBuilder gBuild = new GrammarBuilder();
           
            //append choices
            gBuild.Append(orders);
           
            //need grammer to pass through
            Grammar grammer = new Grammar(gBuild);


            //now we load grammer into the recognition engine
            recEngine.LoadGrammarAsync(grammer); // wont load on main thread, prevents suspension of application

            //defaults voice input device
            recEngine.SetInputToDefaultAudioDevice();

            //checks if the speech is recognized
            recEngine.SpeechRecognized += recEngine_SpeechRecognized;
       }

        //test
        public string time()
        {
            DateTime n = DateTime.Now;
            string o = n.GetDateTimeFormats('t')[0];
            return o;
        }

        //create an event once program picks up voice and reads it
        void recEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            //switch statement gives appropriate response to 
            switch (e.Result.Text)
            {
                case "hello, it's me jacob":

                    //if you want to synthesize this, replace MessageBox.Show with speechSynth.SpeakAsync
                    MessageBox.Show("Hey Jake how's it going?");
                    break;

                case "i'm doing good, how about you?":
                    MessageBox.Show("I'm doing pretty well myself, thanks. You created me and I'm grateful for it.");
                    break;

                case "print my name please":
                    richTextBox1.Text += "\n Jacob Rivera";
                    break;
                case "what is the time":
                    MessageBox.Show(time());
                    break;

                    /* (SAVE FOR LAB PART 3) case "i need to take notes":
                         MessageBox.Show("Notepad Opening, please standby.");
                         System.Diagnostics.Process.Start("notepad.exe");
                         break;

                         //you can make a case that closes the program via System.Diagnostics.Process.Close method
                     case "open chrome":
                         MessageBox.Show("Chrome Opening, please standby. ");
                         System.Diagnostics.Process.Start("chrome.exe");
                         break; */
            }
        }

        private void btnVoiceOff_Click(object sender, EventArgs e)
        {
            //upon clicking the VoiceOff button, ceases the recognition engine
            recEngine.RecognizeAsyncStop();
            btnVoiceOff.Enabled = false;
        }
    }
}