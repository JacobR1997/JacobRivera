var express = require('express');
var http = require('http');
var mysql = require('mysql');
var app = express();
var bodyParser = require('body-parser');
const SQL = require('sql-template-strings');


app.use(bodyParser.urlencoded({ extended:true }));

var dateFormat = require('dateformat')
var now = new Date();

app.set('view engine', 'ejs');

app.use('/js', express.static(__dirname + 'node_modules/bootstrap/dist/js'));
app.use('/js', express.static(__dirname + 'node_modules/tether/dist/js'));
app.use('/js', express.static(__dirname + 'node_modules/jquery/dist'));
app.use('/css', express.static(__dirname + 'node_modules/bootstrap/dist/css'));

const con = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "",
	database: "capstonelab6"
});

const siteTitle = "Jacob Capstone Lab 6";
const baseURL = "http://localhost:4000/"

app.get('/', function (req, res) {

	con.query("SELECT * FROM events ORDER BY eStartDate DESC", function (err, result) {
		res.render('pages/index',{
	 		siteTitle : siteTitle,
			pageTitle : "Event Planner",
			items : result
		});
	});
});


app.get('/event/add', function (req, res) {

	res.render('pages/add-event.ejs',{
	 	siteTitle : siteTitle,
		pageTitle : "Add New Event",
		items : ''
	});
});


app.post('/event/add', function(req, res) {

	var eName = req.body.eName;
		var startDate = dateFormat(req.body.eStartDate, "yyyy-mm-dd");
		var endDate = dateFormat(req.body.eEndDate, "yyyy-mm-dd");
		var eDesc = req.body.eDesc;
		var eLocation = req.body.eLocation;

	var query = SQL `INSERT INTO events (eName, eStartDate, eEndDate, eDesc, eLocation) VALUES(${eName}, ${startDate}, ${endDate}, ${eDesc}, ${eLocation})`

	con.query(query, function(err, result){
		res.redirect(baseURL);  
	});
});


app.get('/event/edit/:id', function(req,res){

	con.query("SELECT * FROM events WHERE eId = '"+ req.params.id + "'", function(err, result){

		result[0].eStartDate = dateFormat(result[0].eStartDate, "yyyy-mm-dd");
		result[0].eEndDate = dateFormat(result[0].eEndDate, "yyyy-mm-dd");

		res.render('pages/edit-event',{
			siteTitle : siteTitle,
			pageTitle : "Editing Event : " + result[0].eName,
			item : result
		});
	});
});

app.post('/event/edit/:id', function(req, res) {
	
		var eId = req.body.eId;
		var eName = req.body.eName;
		var eStartDate = dateFormat(req.body.eStartDate, "yyyy-mm-dd");
		var eEndDate = dateFormat(req.body.eEndDate, "yyyy-mm-dd");
		var eDesc = req.body.eDesc;
		var eLocation = req.body.eLocation;

	var query = SQL `UPDATE events SET eName = ${eName}, eStartDate = ${eStartDate}, eEndDate = ${eEndDate}, eDesc = ${eDesc}, eLocation = ${eLocation} WHERE eId = ${eId}`  


	con.query(query, function(err, result){
			res.redirect(baseURL);  
	});
});


app.get('/event/delete/:id', function(req, res){

 	con.query("DELETE FROM events WHERE eId='"+req.params.id+"'", function(err, result){

		res.redirect(baseURL);

	});
});




		
var server = app.listen(4000, function(){
	console.log("Server started at 4000. Type Localhost:4000 in browser to view. Also make sure the database placement and the credentials are correct!")
});
