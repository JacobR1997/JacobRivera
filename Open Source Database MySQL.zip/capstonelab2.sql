-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 26, 2018 at 09:06 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstonelab2`
--

-- --------------------------------------------------------

--
-- Table structure for table `weatherdata`
--

DROP TABLE IF EXISTS `weatherdata`;
CREATE TABLE IF NOT EXISTS `weatherdata` (
  `weatherID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PrimaryKey',
  `date` date NOT NULL COMMENT 'Individual Dates',
  `temperature` int(11) NOT NULL COMMENT 'Average Temperature',
  `humidity` int(11) NOT NULL COMMENT 'Average Humidity',
  `precipitation` int(11) NOT NULL COMMENT 'Average Precipitation',
  `windSpeed` int(11) NOT NULL COMMENT 'Average Wind Speed',
  `uVIndex` int(11) NOT NULL COMMENT 'UV Index',
  `weatherType` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Weather Type',
  PRIMARY KEY (`weatherID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `weatherdata`
--

INSERT INTO `weatherdata` (`weatherID`, `date`, `temperature`, `humidity`, `precipitation`, `windSpeed`, `uVIndex`, `weatherType`) VALUES
(1, '2018-10-24', 45, 20, 23, 60, 1, 'snow'),
(3, '2018-10-11', 24, 70, 80, 30, 5, 'snow');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
