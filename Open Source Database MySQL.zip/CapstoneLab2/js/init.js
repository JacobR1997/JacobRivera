(function($){
  $(function(){

    $('.button-collapse').sideNav();
	$('.slider').slider();
    $('.parallax').parallax();
	 document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.slider');
    var instances = M.Slider.init(elems, options);
	

  }); // end of document ready
})(jQuery); // end of jQuery name space