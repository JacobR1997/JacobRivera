<html>
<head>
  <title>Rochester Environmental Weather</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>

 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
<nav class="blue" role="navigation">
		<div class="nav-wrapper container">
		<img border = "0" alt="" src="../images/logo.png" width="60" height="60">
		</a>
			<ul class="right hide-on-med-and-down">
				<li><a href="index.php">Home</a>
				<li><a href="addweather.php">Add Weather</a>

			</ul>
			<a href="#" data-activates="nav-mobile" class="button-collapse"<i class="material-icons">menu</i></a>
		</div>	
	</nav>
	
	
<center><h3>Rochester Environmental Weather Tracker</h3></center>
<div class="container">
		<div class="section">
			<center>
			
        <img src="../images/Rochester1.jpg" width="1200" height="500"> 

		</div>
	
<?php

require_once('../mysqli_connect.php');

$query = "SELECT date, temperature, humidity, precipitation, windSpeed, uVIndex, weatherType FROM weatherdata";

$response = @mysqli_query($dbc, $query);

if($response){
		echo'<table align="left"
		cellspacing="5" cellpadding ="8">
		

		<tr><td align="left"><b>Date</b></td>
		<td align="left"><b>Temperature</b></td>
		<td align="left"><b>Humidity</b></td>
		<td align="left"><b>Precipitation</b></td>
		<td align="left"><b>Wind Speed</b></td>
		<td align="left"><b>UV Index</b></td>
		<td align="left"><b>Weather Type</b></td>';
		
		
		while($row = mysqli_fetch_array($response)){
			
			echo '<tr><td align="left">' .
			$row['date'] 				 . '</td><td align="left">' .
			$row['temperature'] 		 . ' *F</td><td align="left">' .
			$row['humidity'] 			 . ' %</td><td align="left">' .
			$row['precipitation'] 		 . ' %</td><td align="left">' .
			$row['windSpeed'] 			 . ' MPH</td><td align="left">' .
			$row['uVIndex'] 			 . '</td><td align="left">' .
			$row['weatherType'] 		 . '</td><td align="left">';
			
			echo '<tr>';
			
		}
		
		echo '</table>';
		
} else {
	
	echo "Database Query went wrong R I P";
	
	echo mysqli_error($dbc);
	
}

mysqli_close($dbc);

?>
			</center>
		</div>
	</div>

  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="../js/materialize.js"></script>
  <script src="../js/init.js"></script>


</body>
</html>