<html>
<head>
<title>Weather Record Added!</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>

 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>

<body>
<nav class="blue" role="navigation">
		<div class="nav-wrapper container">
		<img border = "0" alt="" src="../images/logo.png" width="60" height="60">
		</a>
			<ul class="right hide-on-med-and-down">
				<li><a href="index.php">Home</a>
				<li><a href="addweather.php">Add Weather</a>

			</ul>
			<a href="#" data-activates="nav-mobile" class="button-collapse"<i class="material-icons">menu</i></a>
		</div>	
</nav>
<div class="container">
		<div class="section">	
<?php

if(isset($_POST['submit'])){
	
	$data_missing = array();
	
	if(empty($_POST['date'])){
		
		$data_missing[] = 'Date';
		
	} else {
		
		$date = trim($_POST['date']);
		
	}
	
	if(empty($_POST['temperature'])){
		
		$data_missing[] = 'Temperature';
		
	} else {
		
		$temperature = trim($_POST['temperature']);
		
	}
	
	if(empty($_POST['humidity'])){
		
		$data_missing[] = 'Humidity';
		
	} else {
		
		$humidity = trim($_POST['humidity']);
		
	}
	
	if(empty($_POST['precipitation'])){
		
		$data_missing[] = 'Precipitation';
		
	} else {
		
		$precipitation = trim($_POST['precipitation']);
		
	}
	
	if(empty($_POST['windSpeed'])){
		
		$data_missing[] = 'Wind Speed';
		
	} else {
		
		$windSpeed = trim($_POST['windSpeed']);
		
	}
	
	if(empty($_POST['uVIndex'])){
		
		$data_missing[] = 'UV Index';
		
	} else {
		
		$uVIndex = trim($_POST['uVIndex']);
		
	}
	
	if(empty($_POST['weatherType'])){
		
		$data_missing[] = 'weatherType';
		
	} else {
		
		$weatherType = trim($_POST['weatherType']);
		
	}
	
	if(empty($data_missing)){
		 
		require_once('../mysqli_connect.php');
		$query = "INSERT INTO weatherdata (date, temperature, humidity, precipitation, windSpeed, uVIndex, weatherType) 
				  VALUES (?, ?, ?, ?, ?, ?, ?)";
				  
		$stmt = mysqli_prepare($dbc, $query);
		
		
		
			
		mysqli_stmt_bind_param($stmt, "siiiiis", $date, $temperature, $humidity, $precipitation, $windSpeed, $uVIndex, $weatherType);
		
		mysqli_stmt_execute($stmt);
		

        $affected_rows = mysqli_stmt_affected_rows($stmt);

		
		 if($affected_rows == 1){
			 
			 echo 'Weather Entered!';
		 
            mysqli_stmt_close($stmt);
          
            mysqli_close($dbc);

			
        } else {
            
            echo 'Error Occurred<br />';

            echo mysqli_error($dbc);             

            mysqli_stmt_close($stmt);

            mysqli_close($dbc);
			
		}
            
        } else {
			echo 'You must enter the following data to continue<br />';
			
			foreach($data_missing as $missing){
				
				echo "$missing<br />";
			}
			
		}	
		
	}	

?>

<form action ="http://localhost/CapstoneLab2/DBInfo/weatheradded.php" method="post">

		</br>
		<b>Add a new Weather Recording</b>
		
		<p>Date (MM-DD-YYYY): 
		<input type="date" name="date" size="30" value=""/>
		</p>
		
		<p>Temperature (*F): 
		<input type="number" name="temperature" size="30" maxlength="3" max="130" min="-50" value=""/>
		*F
		</p>
		
		<p>Humidity (0-100%): 
		<input type="number" name="humidity" size="30" max="100" min="0" maxlength="3" value=""/>
		%
		</p>
		
		<p>Precipitation (0-100%): 
		<input type="number" name="precipitation" size="30" max="100" min="0" value=""/>
		%
		</p>
		
		<p>Wind Speed (MPH): 
		<input type="number" name="windSpeed" size="30" max="120" min="0" value=""/>
		MPH
		</p>
		
		<p>UV Index (Between 1 and 10): 
		<input type="number" name="uVIndex" size="30" max="10" min="1" value="" />
		</p>	
		
		<p>Weather Type (Ex: Rain/Snow/Cloudy/Sunny): 
		<input type="text" name="weatherType" size="30" value=""/>
		</p>
		
		<p>
		<input type="submit" name="submit" value="Send"/>
</div>
</div>
</form>
</body>
</html>