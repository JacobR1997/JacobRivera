<?php

	DEFINE('DB_USER', 'root');
	DEFINE('DB_PASSWORD', '');
	DEFINE('DB_HOST', 'localhost');
	DEFINE('DB_NAME', 'capstonelab2');
	
	$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
	OR die('Whoops! Something went wrong. R I P     ' . mysqli_connect_error());
	
?>