from flask import Flask, render_template, flash, redirect, url_for, session, request, logging
#from data import Shortstories
from flask_mysqldb import MySQL
from wtforms import Form, StringField, TextAreaField, PasswordField, validators
from passlib.hash import sha256_crypt
from functools import wraps


app = Flask(__name__)

# Config MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Jacob1997'
app.config['MYSQL_DB'] = 'capstoneapp'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
#init MYSQL
mysql = MySQL(app)

#Shortstories = Shortstories()



@app.route('/')
def index():
		return render_template('index.html')


@app.route('/about')
def about():
	return render_template('about.html')



@app.route('/shortstories')
def shortstories():
	cur = mysql.connection.cursor()


	result = cur.execute("SELECT * FROM shortstories")

	shortstories = cur.fetchall()

	if result > 0:
		return render_template('shortstories.html', shortstories=shortstories)
	else:
		msg = 'No Short Stories Found, something went wrong!'
		return render_template('shortstories.html', msg=msg)

	cur.close()



@app.route('/shortstory/<string:id>/')
def shortstory(id):
	cur = mysql.connection.cursor()


	result = cur.execute("SELECT * FROM shortstories WHERE id = %s", [id])

	shortstory = cur.fetchone()
	return render_template('shortstory.html', shortstory = shortstory)





class RegisterForm(Form):
	name = StringField('Name', [validators.Length(min=1, max=50)])
	username = StringField('Username', [validators.Length(min=4, max=25)])
	email = StringField('Email', [validators.Length(min=6, max=50)])
	password = PasswordField('Password', [
		validators.DataRequired(),
		validators.EqualTo('confirm', message='Entered passwords do not match.')
	])
	confirm = PasswordField('Confirm Password')







@app.route('/register', methods=['GET', 'POST'])
def register():
	form = RegisterForm(request.form)
	if request.method == 'POST' and form.validate():
		name = form.name.data
		email = form.email.data
		username = form.username.data
		password = sha256_crypt.encrypt(str(form.password.data))

		# Create cursor
		cur = mysql.connection.cursor()

		# Executes MySQL Query
		cur.execute("INSERT INTO users(name, email, username, password) VALUES(%s, %s, %s, %s)", (name, email, username, password))

		#Commit to the Database
		mysql.connection.commit()

		#close the database connection after committing
		cur.close()

		flash('You are now registered and are able to log in!', 'success')


		return redirect(url_for('login'))
	return render_template('register.html', form=form)



#user login
@app.route('/login' , methods=['GET', 'POST'])	
def login():
	if request.method == 'POST':
		#get fields from the form
		username = request.form['username']
		password_candidate = request.form['password']

		#Create the cursor
		cur = mysql.connection.cursor()

		#Get user by the username
		result = cur.execute("SELECT * FROM users WHERE username = %s", [username])

		if result > 0:
			#get hash
			data = cur.fetchone()
			password = data['password']

			#compare the passwords in database
			if sha256_crypt.verify(password_candidate, password):
				#Passed Password
				session['logged_in'] = True
				session['username'] = username

				flash('Logged in successfully!', 'success')
				return redirect(url_for('dashboard'))			
			else:
				error = 'Error! Invalid login.'
				return render_template('login.html', error=error)
			cur.close()

		else:
			error = 'Username not found.'
			return render_template('login.html', error=error)

	return render_template('login.html')

#checks if a user is logged in or not
def is_logged_in(f):
	@wraps(f)
	def wrap(*args, **kwargs):
		if 'logged_in' in session:
			return f(*args, **kwargs)
		else:
			flash('Pretty sneaky! Please log in or register...', 'danger')
			return redirect(url_for('login'))
	return wrap




@app.route('/logout')
@is_logged_in
def logout():
	session.clear()
	flash('Successfully logged out.', 'success')
	return redirect(url_for('login'))




@app.route('/dashboard')
@is_logged_in
def dashboard():
	cur = mysql.connection.cursor()


	result = cur.execute("SELECT * FROM shortstories")

	shortstories = cur.fetchall()

	if result > 0:
		return render_template('dashboard.html', shortstories=shortstories)
	else:
		msg = 'No Short Stories Found, something went wrong!'
		return render_template('dashboard.html', msg=msg)

	cur.close()
	

class ShortstoryForm(Form):
	title = StringField('Title', [validators.Length(min=1, max=200)])
	body = TextAreaField('Body', [validators.Length(min=30)])



@app.route('/add_shortstory', methods=['GET', 'POST'])
@is_logged_in
def add_shortstory():
	form = ShortstoryForm(request.form)
	if request.method == 'POST' and form.validate():
		title = form.title.data
		body = form.body.data

		cur = mysql.connection.cursor()

		cur.execute("INSERT INTO shortstories(title, body, author) VALUES(%s, %s, %s)", (title, body, session['username']))

		mysql.connection.commit()

		cur.close()

		flash('Short Story Submitted', 'success')

		return redirect(url_for('dashboard'))

	return render_template('add_shortstory.html', form=form)


@app.route('/edit_shortstory/<string:id>', methods=['GET', 'POST'])
@is_logged_in
def edit_shortstory(id):
	cur = mysql.connection.cursor()

	result = cur.execute("SELECT * FROM shortstories WHERE id = %s", [id])

	shortstory = cur.fetchone()

	form = ShortstoryForm(request.form)

	form.title.data = shortstory['title']
	form.body.data = shortstory['body']

	if request.method == 'POST' and form.validate():
		title = request.form['title']
		body = request.form['body']

		cur = mysql.connection.cursor()

		cur.execute("UPDATE shortstories SET title=%s, body=%s WHERE id = %s", (title, body, id))

		mysql.connection.commit()

		cur.close()

		flash('Short Story Edited', 'success')

		return redirect(url_for('dashboard'))

	return render_template('edit_shortstory.html', form=form)
	

@app.route('/delete_shortstory/<string:id>', methods=['POST'])
@is_logged_in
def delete_shortstory(id):
	cur = mysql.connection.cursor()

	cur.execute("DELETE FROM shortstories WHERE id = %s", [id])

	mysql.connection.commit()

	cur.close()

	flash('Short Story Deleted', 'success')

	return redirect(url_for('dashboard'))



if __name__ == '__main__':
	app.secret_key='secret123'
	app.run(debug=True)